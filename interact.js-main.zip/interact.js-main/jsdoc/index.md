# API Reference

<img
  style="background-color: #272822; display: block; margin: auto; max-height: 8em; width: 100%"
  alt="interact.js"
  src="img/ijs-anim-short.svg">
