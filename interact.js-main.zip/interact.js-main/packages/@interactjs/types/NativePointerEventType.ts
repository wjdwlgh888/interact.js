const NativePointerEvent = (null as unknown) as InstanceType<typeof PointerEvent>
export default NativePointerEvent
