export default (x: number, y: number) => Math.sqrt(x * x + y * y)
